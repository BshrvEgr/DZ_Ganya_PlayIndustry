﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basharov.Solodkov.Drozdov.PlayIndustry.ViewModel
{
    public class MainViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public void Update(string property)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));
        }

        private List<PlayBuilds> playBuilds;
        private List<Computer> computers;

        public List<PlayBuilds> PlayBuilds
        {
            get { return playBuilds; }
            set { playBuilds = value; Update("PlayBuilds"); }
        }

        public List<Computer> Computers
        {
            get { return computers; }
            set { computers = value; Update("Computers"); }
        }
    }
}
